### Sound effects used in the game

Click the (file)name to go to the original download page.

- all sounds in folder [`blood/`](https://freesound.org/people/VlatkoBlazek/sounds/318592/) **by** VlatkoBlazek [(CC BY 3.0)](https://creativecommons.org/licenses/by/3.0/) (adapted)
- [`energy.ogg`](https://freesound.org/people/ejfortin/sounds/49693/) **by** ejfortin [(Sampling Plus 1.0)](https://creativecommons.org/licenses/sampling+/1.0/) (adapted)

